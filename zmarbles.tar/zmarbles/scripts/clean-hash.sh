#!/bin/bash

# Clear out marbles app hash
HASH='"last_startup_hash": ""'
cd ~/zmarbleslab
sed -i '12d' marbles/config/marbles1.json
sed -i '12d' marbles/config/marbles2.json
sed -i '12i\    '"${HASH}" marbles/config/marbles1.json
sed -i '12i\    '"${HASH}" marbles/config/marbles2.json
pkill -f 'node app.js'

