#!/bin/bash

if [ -z $1 ]; then
  echo "Error: Please specify the channel name."
  echo "Usage: setup-marbles.sh <channel-name>"
  echo ""
  exit 1
fi

# Create channel
peer channel create -o orderer.blockchain.com:7050 -c $1 -f crypto/orderer/channel.tx --tls --cafile /opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/orderer/localMspConfig/cacerts/blockchain.com-cert.pem

# Channel join
. scripts/setpeer 0 0
peer channel join -o orderer.blockchain.com:7050 -b $1.block 

. scripts/setpeer 0 1
peer channel join -o orderer.blockchain.com:7050 -b $1.block

. scripts/setpeer 1 0
peer channel join -o orderer.blockchain.com:7050 -b $1.block

. scripts/setpeer 1 1
peer channel join -o orderer.blockchain.com:7050 -b $1.block

# Update Anchor peers
. scripts/setpeer 0 0
peer channel create -o orderer.blockchain.com:7050 -c $1 -f crypto/orderer/Org0MSPanchors.tx --tls --cafile /opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/orderer/localMspConfig/cacerts/blockchain.com-cert.pem

. scripts/setpeer 1 0
peer channel create -o orderer.blockchain.com:7050 -c $1 -f crypto/orderer/Org1MSPanchors.tx --tls --cafile /opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/orderer/localMspConfig/cacerts/blockchain.com-cert.pem

# Install marbles chaincode on peer0/org0 and peer0/org1
. scripts/setpeer 0 0
peer chaincode install -n marbles -v 1.0 -p github.com/hyperledger/fabric/examples/chaincode/go/marbles
. scripts/setpeer 1 0
peer chaincode install -n marbles -v 1.0 -p github.com/hyperledger/fabric/examples/chaincode/go/marbles

# Instantiate marbles chaincode
. scripts/setpeer 0 0
peer chaincode instantiate -o orderer.blockchain.com:7050 -C $1 -n marbles -v 1.0 -c '{"Args":["init","1"]}' -P "OR ('Org0MSP.member','Org1MSP.member')" --tls --cafile /opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/orderer/localMspConfig/cacerts/blockchain.com-cert.pem
sleep 10

# Create marbles owner
peer chaincode invoke -C $1 -o orderer.blockchain.com:7050 -n marbles -c '{"Args":["init_owner","o0000000000001","john","Marbles Inc"]}' --tls --cafile /opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/orderer/localMspConfig/cacerts/blockchain.com-cert.pem
sleep 5

# Create marble 
peer chaincode invoke -C $1 -o orderer.blockchain.com:7050 -n marbles -c '{"Args":["init_marble","m0000000000001","blue","35","o0000000000001","Marbles Inc"]}' --tls --cafile /opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/orderer/localMspConfig/cacerts/blockchain.com-cert.pem


# Create 2nd marbles owner
. scripts/setpeer 1 0
peer chaincode invoke -C $1 -o orderer.blockchain.com:7050 -n marbles -c '{"Args":["init_owner","o0000000000002","barry","United Marbles"]}' --tls --cafile /opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/orderer/localMspConfig/cacerts/blockchain.com-cert.pem
sleep 5

# Create marble for 2nd owner
peer chaincode invoke -C $1 -o orderer.blockchain.com:7050 -n marbles -c '{"Args":["init_marble","m0000000000002","green","35","o0000000000002","United Marbles"]}' --tls --cafile /opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/orderer/localMspConfig/cacerts/blockchain.com-cert.pem

